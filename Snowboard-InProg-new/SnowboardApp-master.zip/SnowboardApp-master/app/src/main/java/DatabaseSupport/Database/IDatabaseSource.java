package DatabaseSupport.Database;

public interface IDatabaseSource {
}
